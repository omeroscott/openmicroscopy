.. python-sqlparse documentation master file, created by
   sphinx-quickstart on Thu Feb 26 08:19:28 2009.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

python-sqlparse's documentation contents
========================================

.. toctree::
   :maxdepth: 2

   intro
   api
   analyzing
   ui
   changes


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

