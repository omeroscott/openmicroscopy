.. _changes:

Changes in python-sqlparse
==========================

.. include:: ../../CHANGES

